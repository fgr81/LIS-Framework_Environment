.. _ind_developers:

==========
Developers
==========

Information for PETSc developers and those interested in contributing.

.. toctree::
   :maxdepth: 1

   communication
   contributing/index
   mrmanagement
   development
   style
   buildsystem
   testing
   documentation
   design
