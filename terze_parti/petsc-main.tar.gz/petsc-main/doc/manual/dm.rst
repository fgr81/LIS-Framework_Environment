.. _part_dm:

DM: Interfacing Between Solvers and Models/Discretizations
==========================================================

.. toctree::
   :maxdepth: 2

   dmbase
   dmplex
   dmstag
   dmnetwork
   dt
   fe
