#!/bin/sh

. ./include.sh

$PYTHON $examples_src/grib_nearest.py
