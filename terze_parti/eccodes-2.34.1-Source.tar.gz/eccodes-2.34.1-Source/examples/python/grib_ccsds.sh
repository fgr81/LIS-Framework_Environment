#!/bin/sh

. ./include.sh

$PYTHON $examples_src/grib_ccsds.py

