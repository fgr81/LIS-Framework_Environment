/*
 * NetCDF C Test for PnetCDF Support
 */
#include "netcdf_meta.h"

int main()
{
#if NC_HAS_PNETCDF==1
	return 0;
#else
	XXX;
#endif
}
