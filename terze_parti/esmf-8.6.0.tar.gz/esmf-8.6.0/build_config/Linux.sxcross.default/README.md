## Linux, using the NEC SX cross-compiler

Activated by setting: `ESMF_COMPILER=sxcross`

Settings for the NEC SX, with a cross-compiler running on a Linux front end.
