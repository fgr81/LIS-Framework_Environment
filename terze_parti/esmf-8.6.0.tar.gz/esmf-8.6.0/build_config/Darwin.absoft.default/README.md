## Darwin, using the commercial Absoft Fortran compiler

Activated by setting: `ESMF_COMPILER=absoft`

Settings for Darwin (Mac OS X), using the commercial Absoft Fortran compiler
and the GNU C++ compiler (g++).
