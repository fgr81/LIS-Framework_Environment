## Unicos, using the NVIDIA HPC compilers

Activated by setting: `ESMF_COMPILER=nvhpc`

Settings for Linux/lc on Cray, using the NVIDIA HPC compilers.
