## Darwin, using the PGI compilers

Activated by setting: `ESMF_COMPILER=pgi`

Settings for Darwin (Mac OS X), using the community and commercial
Portland Group PGI Fortran and C++ compilers.

