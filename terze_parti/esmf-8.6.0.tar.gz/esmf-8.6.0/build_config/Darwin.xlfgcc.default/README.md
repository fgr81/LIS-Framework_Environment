## Darwin, using the IBM Fortran compiler with GNU C/C++ compiler

Activated by setting: `ESMF_COMPILER=xlfgcc`

Settings for Darwin (Mac OS X), using the commercial IBM xlf Fortran compiler
and GNU C++ compiler (g++).

