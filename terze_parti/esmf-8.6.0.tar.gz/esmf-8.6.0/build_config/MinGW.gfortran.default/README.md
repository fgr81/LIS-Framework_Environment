## MinGW, using the GNU compilers

Activated by setting: `ESMF_COMPILER=gfortran`

Settings for MinGW/MSYS using the GNU gfortran compiler.

Notes:

1.) This port was performed under Windows HPC Server 2008,
using MinGW 6.1 and MSYS 1.0.11.  MinGW and MSYS are available
from http://www.mingw.org.

2.) The MinGW version of gcc is required for preprocessing.
