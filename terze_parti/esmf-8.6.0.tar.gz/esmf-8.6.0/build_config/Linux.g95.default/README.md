## Linux, using the g95 Fortran compiler

Activated by setting: `ESMF_COMPILER=g95`

Settings for Linux, using the GNU g95 compiler and the GNU C++
compiler (g++).
