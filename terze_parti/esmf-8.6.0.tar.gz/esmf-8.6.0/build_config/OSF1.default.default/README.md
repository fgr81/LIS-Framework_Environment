## OSF1, using the commercial HP compiler suite

Activated by default.

Settings for HP/Compaq cluster running OSF1, using the HP Fortran and C++ compilers.
