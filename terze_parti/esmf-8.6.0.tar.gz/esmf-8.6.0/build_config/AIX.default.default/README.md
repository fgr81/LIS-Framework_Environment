## AIX, using the IBM compilers

Settings for IBM AIX systems using the xlf and xlC compilers.

Default ESMF_ABI is 64. To compile for 32-bit set ESMF_ABI to 32.

