## Linux, using the PGI Fortran compiler with GNU C/C++

Activated by setting: `ESMF_COMPILER=pgigcc`

Settings for Linux, using the commercial Portland Group PGI Fortran compiler
and the GNU C++ compiler (g++).
