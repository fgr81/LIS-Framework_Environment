## Linux, using the NVIDIA HPC compilers

Activated by setting: `ESMF_COMPILER=nvhpc`

Settings for Linux, using the NVIDIA HPC compilers.
