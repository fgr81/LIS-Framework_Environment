## Unicos, using the Cray compilers

Activated by default.

Settings for Cray Unicos system, X1, using the Cray Fortran and C++ compilers.
