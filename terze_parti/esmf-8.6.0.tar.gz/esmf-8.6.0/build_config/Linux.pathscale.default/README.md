## Linux, using the Pathscale Fortran compiler with GNU C/C++

Activated by setting: `ESMF_COMPILER=pathscale`

Settings for Linux, using the commercial Pathscale Fortran compiler and the
GNU C++ compiler (g++).
