## Linux, using the LLVM compilers

Activated by setting: `ESMF_COMPILER=llvm`

Settings for Linux, using the LLVM compilers: clang and flang-new.

CAUTION:
This configuration, last tested with LLVM 15.0.1 from https://github.com/llvm/llvm-project.git,
has NOT been able to successfully build the ESMF library. The configuration is included with
ESMF for future testing with LLVM, and will likely require modifications.
