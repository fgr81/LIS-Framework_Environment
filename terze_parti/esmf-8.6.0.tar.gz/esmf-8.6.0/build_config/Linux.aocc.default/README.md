## Linux, using the AMD compilers

Activated by setting: `ESMF_COMPILER=aocc`

Settings for Linux, using the AMD Optimized Compilers (AOCC).

