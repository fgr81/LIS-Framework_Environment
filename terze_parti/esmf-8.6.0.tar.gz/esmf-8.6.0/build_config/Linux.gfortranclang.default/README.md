## Linux, using the GNU Fortran compiler with LLVM Clang C/C++

Activated by setting: `ESMF_COMPILER=gfortranclang`

Settings for Linux, using the clang C++ compiler and GNU gfortran compiler.
