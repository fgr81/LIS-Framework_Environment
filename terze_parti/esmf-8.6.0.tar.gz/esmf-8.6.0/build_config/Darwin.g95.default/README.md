## Darwin, using the g95 Fortran compiler

Activated by setting: `ESMF_COMPILER=g95`

Settings for Darwin (Mac OS X), using the g95 compiler and the GNU C++
compiler (g++).
