## SunOS, using the commercial SUNWspro compiler suite

Activated by default.

Settings for SunOS, using the SUNWspro Fortran and C++ compilers.

Default ESMF_ABI is 64. To compile for 32-bit set ESMF_ABI to 32.
