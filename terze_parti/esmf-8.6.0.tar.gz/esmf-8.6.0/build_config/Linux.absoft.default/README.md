## Linux, using the commercial Absoft compiler

Activated by setting: `ESMF_COMPILER=absoft`

Settings for Linux, using the commercial Absoft Fortran compiler and the 
GNU C++ compiler (g++).

