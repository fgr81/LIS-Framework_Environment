## Linux, using the PGI compilers

Activated by setting: `ESMF_COMPILER=pgi`

Settings for Linux, using the commercial Portland Group PGI Fortran and C++ compilers.
