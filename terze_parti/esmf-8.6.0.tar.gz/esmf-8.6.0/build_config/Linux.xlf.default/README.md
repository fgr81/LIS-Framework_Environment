## Linux, using the IBM compilers

Activated by setting: `ESMF_COMPILER=xlf`

Settings for IBM Blue Gene/Q system, which runs Linux, using the IBM xlf Fortran
and C++ compilers.
