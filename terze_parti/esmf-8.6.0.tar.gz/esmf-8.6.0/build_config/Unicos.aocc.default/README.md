## Unicos, using the AMD compilers

Activated by setting: `ESMF_COMPILER=aocc`

Settings for Unicos/lc on Cray, using the AMD Optimized Compilers (AOCC).
