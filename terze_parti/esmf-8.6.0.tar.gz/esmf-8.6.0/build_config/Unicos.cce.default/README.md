## Unicos, using the Cray compilers

Activated by setting: `ESMF_COMPILER=cce`

Settings for Unicos/lc on Cray XT, using the Cray Compiler Environment (CCE) suite.
