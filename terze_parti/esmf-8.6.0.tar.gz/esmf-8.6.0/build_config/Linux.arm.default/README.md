## Linux, using the ARM compilers

Activated by setting: `ESMF_COMPILER=arm`

Settings for Linux, using the ARM compilers: armclang and armflang.
