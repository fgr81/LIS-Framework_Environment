## Darwin, using the Intel compilers

Activated by setting: `ESMF_COMPILER=intel`

Settings for Darwin (Mac OS X) machines with Intel processors, using the
commercial Intel Fortran (ifort) and C++ (icpc) compilers.
