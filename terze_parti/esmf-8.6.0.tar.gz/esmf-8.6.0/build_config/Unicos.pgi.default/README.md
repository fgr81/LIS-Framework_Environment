## Unicos, using the PGI compilers

Activated by setting: `ESMF_COMPILER=pgi`

Settings for Unicos/lc on Cray XT, using the Portland Group PGI Fortran and C++ compilers.
