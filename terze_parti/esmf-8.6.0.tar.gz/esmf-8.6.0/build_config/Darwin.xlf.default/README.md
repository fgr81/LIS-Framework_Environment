## Darwin, using the IBM compilers

Activated by setting: `ESMF_COMPILER=xlf`

Settings for Darwin (Mac OS X), using the commercial IBM xlf Fortran compiler
and IBM xlC C++ compiler.


