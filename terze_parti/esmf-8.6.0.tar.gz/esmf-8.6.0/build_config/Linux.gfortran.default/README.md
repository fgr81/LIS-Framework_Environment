## Linux, using the GNU compilers

Activated by setting: `ESMF_COMPILER=gfortran`

Settings for Linux, using the GNU gfortran compiler and GNU C++ compiler (g++).
