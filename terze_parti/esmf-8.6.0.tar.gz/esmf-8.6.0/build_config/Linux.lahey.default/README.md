## Linux, using the commercial Lahey Fortran compiler with GNU C/C++

Activated by setting: `ESMF_COMPILER=lahey`

Settings for Linux, using the commercial Lahey Fortran compiler and the
GNU C++ compiler (g++).
