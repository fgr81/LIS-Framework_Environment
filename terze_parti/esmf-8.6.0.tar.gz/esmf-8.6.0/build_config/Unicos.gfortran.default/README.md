## Unicos, using the GNU compilers

Activated by setting: `ESMF_COMPILER=gfortran`

Settings for Unicos/lc on Cray XT/XE/XK/EX, using gfortran and g++ out of the GNU Compiler Collection.
