## Linux, using the commercial Intel Fortran compiler with GNU C/C++

Activated by setting: `ESMF_COMPILER=intelgcc`

Settings for Linux, using the commercial Intel Fortran compiler (ifort) and 
GNU C++ compiler (g++).
