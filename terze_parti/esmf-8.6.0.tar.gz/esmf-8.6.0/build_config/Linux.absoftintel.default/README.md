## Linux, using the Absoft Fortran compiler with Intel C/C++ compiler

Activated by setting: `ESMF_COMPILER=absoftintel`

Settings for Linux, using the commercial Absoft Fortran compiler and the 
commercial Intel C++ compiler (icpc).

