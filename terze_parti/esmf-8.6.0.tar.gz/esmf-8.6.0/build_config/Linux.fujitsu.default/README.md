## Linux, using the Fujitsu compilers

Activated by setting: `ESMF_COMPILER=fujitsu`

Settings for Linux, using the Fujitsu compilers: FCC, fcc, frt
