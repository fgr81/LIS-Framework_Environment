## Unicos, using the PathScale compilers

Activated by setting: `ESMF_COMPILER=pathscale`

Settings for Unicos/lc on Cray XT, using the PathScale compiler suite.
