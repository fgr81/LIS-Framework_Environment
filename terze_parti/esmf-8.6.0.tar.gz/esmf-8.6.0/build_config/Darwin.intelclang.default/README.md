## Darwin, using the Intel Fortran compiler with LLVM Clang C/C++ compiler

Activated by setting: `ESMF_COMPILER=intelclang`

Settings for Darwin (Mac OS X) machines with Intel processors, using the
commercial Intel Fortran (ifort) compiler and the Apple clang/llvm C++
compiler.
